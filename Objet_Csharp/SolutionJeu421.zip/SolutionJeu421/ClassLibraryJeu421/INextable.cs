﻿using System.Runtime.CompilerServices;

namespace ClassLibraryJeu421
{

    public interface INextable
    {
        int Nouveau(int _valMin, int _valMax);
    }
}